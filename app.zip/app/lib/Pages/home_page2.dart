import 'package:flutter/material.dart';

void main(){
  runApp(new MaterialApp(
    title: "Productos",
    home: new Productos(),
  ));
}

class Productos extends StatefulWidget {
  @override
  _ProductosState createState() => _ProductosState();
}


class _ProductosState extends State<Productos> {
List<Container> dataProductos  = new List();

var products = [
  {"Nombre":"mesa","Imagen":"3020029_1.jpg"},
  {"Nombre":"sillon Azul","Imagen":"3476057_1.jpg"},
  {"Nombre":"Mueble","Imagen":"3672471_1.jpg"},
  {"Nombre":"Silla","Imagen":"4007839_1.jpg"},
  {"Nombre":"Sillon","Imagen":"3996586_1.jpg"},
  {"Nombre":"Estante","Imagen":"3853242_1.jpg"},
];

_constlist()async{
  for(var i=0; i<products.length; i++){
      final Product = products[i];
      dataProductos..add(
        new Container(
          child:new Text(Product["Nombre"])
        )
      );

    }
}
  @override
  Widget build(BuildContext context) {
    return  new Scaffold(
      appBar: new AppBar(
        title: new Text("Productos", style: new TextStyle(color: Colors.white))
      ),
      body: new GridView.count(
        crossAxisCount: 2,
        children: dataProductos,
      ),
    );
  }
}
